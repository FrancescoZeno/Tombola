#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

class GenNum
{
private:
    vector<int> numeri_usati;

public:
    vector<int> numero;
    int cont_pos = 0;
    GenNum()
    {
        for (int i = 0; i < 90; ++i)
        {
            numero.push_back(i + 1);
        }
        random_shuffle(numero.begin(), numero.end());
    }

    int getNumero()
    {
        if (cont_pos < numero.size())
        {
            int num;
            do
            {
                num = numero[cont_pos++];
            } while (find(numeri_usati.begin(), numeri_usati.end(), num) != numeri_usati.end());
            numeri_usati.push_back(num);
            return num;
        }
        else
        {
            return -1;
        }
    }
};

class Player : public GenNum
{
private:
    int tabella[5][5];

public:
    Player()
    {
        memset(tabella, 0, sizeof(tabella));

        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                int num;
                do
                {
                    num = numero[cont_pos++];
                } while (checkNumeroUtilizzato(num));
                tabella[i][j] = num;
            }
        }
    }

    bool checkNumeroUtilizzato(int num)
    {
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (tabella[i][j] == num)
                {
                    return true;
                }
            }
        }
        return false;
    }

    void Stampa()
    {
        cout << "|    T A B E L L A    |" << endl;
        cout << "---------------------------------------------" << endl;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                cout << "|   " << tabella[i][j] << "   ";
            }
            cout << "|" << endl;
            cout << "---------------------------------------------" << endl;
        }
    }
};

int main()
{
    srand(time(NULL));
    GenNum panaro;
    Player x1;
    int scelta_switch;

    for (int i = 0; i < 90; i++)
    {
        cout << panaro.numero[i] << " - ";
    }
    x1.Stampa();

    system("pause");

    // do
    // {
    //     system("cls");
    //     cout << "Menu:" << endl;
    //     cin >> scelta_switch;

    //     switch (scelta_switch)
    //     {
    //     }
    // } while (scelta_switch != 0);
    // cout << "Numeri estratti dal panaro:" << endl;
    // for (int i = 0; i < 15; ++i)
    // {
    //     int num = panaro.getNumero();
    //     if (num != -1)
    //     {
    //         cout << num << " ";
    //     }
    //     else
    //     {
    //         cout << "Tutti i numeri sono stati utilizzati." << endl;
    //         break;
    //     }
    // }
    cout << endl;
    cin.get();
    return 0;
}
