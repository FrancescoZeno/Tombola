#include <iostream>
#include <cstdlib>
#include "struttura_dati.h"
using namespace std;

bool controllo_vincita();
void controlla_numero();

/*---------------FUNZIONI---------------*/
bool controllo_vincita()
{
    int cont = 0;
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (x1.getNumeroScheda(i, j) == -1)
            {
                cont++;
            }
        }
    }
    if (cont == 15)
    {
        return true;
    }
    else
    {
        return false;
    }
}
/**/
void controlla_numero()
{
    int num = panaro.getNumero();
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (num == x1.getNumeroScheda(i, j))
            {
                x1.ModificaNumero(i, j, num);
            }
        }
    }
}